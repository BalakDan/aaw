---
name: "AIP Discussion"
about: Discuss Aptos Improvement Proposal, getting feedback
title: "[AIP-X][Discussion]"
labels: discussion
assignees: ''

---

# AIP Discussion

< Copy Summary of AIP here in md >

Read more about it here: < Link to AIP >
